To run the source file, please move the the code to the **root directory** and making file tree likes this:

> root
> │  si618_project1_junqich.py
> │  si618_project1_junqich_visualization.ipynb
> │  si618_project_part1_junqich.pdf
> │
> ├─data
> │      country_vaccinations.csv
> │      covid.csv
> │
> └─result
>         junqich_si618_project_q1-1.csv
>         junqich_si618_project_q1-2.csv
>         junqich_si618_project_q1.csv
>         junqich_si618_project_q2-1.csv
>         junqich_si618_project_q2-2.csv
>         junqich_si618_project_q2.csv
>         junqich_si618_project_q3-1.csv
>         junqich_si618_project_q3-2.csv

